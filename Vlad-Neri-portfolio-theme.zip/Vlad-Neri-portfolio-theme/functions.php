<?php

function mikael_load_assets() {
    // 1. Load the Main Stylesheet (Using time() to completely bypass Chrome's cache)
    wp_enqueue_style('mikael-main-style', get_stylesheet_uri(), [], time());

    // 2. Load FontAwesome (CRITICAL for the Sidebar & Dock Icons)
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

    // 3. Load GSAP & Barba (For the animations)
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', [], null, true);
    wp_enqueue_script('barba', 'https://unpkg.com/@barba/core', [], null, true);

    // 4. Load Custom Logic (Using time() to bypass cache for the JS file too)
    wp_enqueue_script('mikael-app', get_template_directory_uri() . '/assets/app.js', ['gsap', 'barba'], time(), true);
}
add_action('wp_enqueue_scripts', 'mikael_load_assets');

// Enable Menus and Dynamic Title Support
function mikael_theme_setup() {
    register_nav_menus(['primary' => 'Main Menu']);
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'mikael_theme_setup');

?>