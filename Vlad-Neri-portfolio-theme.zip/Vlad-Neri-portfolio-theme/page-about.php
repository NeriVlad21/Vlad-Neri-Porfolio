<?php /* Template Name: About Page */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <div class="about-hero-container animate-up">
        
        <div class="profile-img-wrapper">
            <img src="<?php echo get_template_directory_uri(); ?>/face.jpg" alt="Vlad Neri" class="profile-hero-img">
        </div>

        <div class="text-content">
            <h2 class="section-title" style="margin-bottom: 20px;">About Me</h2>
            
            <p>
                I am a <span class="highlight">4th Year Computer Science Student</span> at PHINMA UPang, based in <span class="highlight">Rosario, La Union</span>. 
                I specialize in <span class="underline-blue">Full-Stack Development</span> and Data Analytics.
            </p>
            
            <p>
                My journey into tech is driven by curiosity and hustle. I balance my academic studies with <span class="highlight">part-time roles</span> and <span class="highlight">summer freelance projects</span>, managing social media for influencers and building software solutions for local problems.
            </p>
        </div>
    </div>

    <div class="animate-up">
        <h3 class="subsection-title">The Specs</h3>
        <ul class="specs-list">
            <li>
                <span class="spec-label">Location:</span> 
                Tabtabungao, Rosario, La Union
            </li>
            <li>
                <span class="spec-label">Languages:</span> 
                English, Filipino, Bisaya (Cebuano), Waray 
            </li>
            <li>
                <span class="spec-label">Education:</span> 
                BS Computer Science (PHINMA UPang)
            </li>
        </ul>
    </div>

    <div class="animate-up">
        <h3 class="subsection-title">Tech Stack</h3>
        <div class="tech-stack-row">
            <span class="tech-pill">PHP</span>
            <span class="tech-pill">Python</span>
            <span class="tech-pill">Kotlin</span>
            <span class="tech-pill">Java</span>
            <span class="tech-pill">JavaScript</span>
            <span class="tech-pill">SQL</span>
            <span class="tech-pill">VS Code</span>
            <span class="tech-pill">Android Studio</span>
            <span class="tech-pill">Figma</span>
            <span class="tech-pill">Kali Linux</span>
            <span class="tech-pill">DaVinci Resolve</span>
        </div>
    </div>

    <div class="cert-section animate-up" style="margin-top: 60px; padding-bottom: 40px;">
        <h3 class="subsection-title">Certifications & Awards</h3>
        
        <div class="cert-gallery-container">
            <div class="cert-track">
                <img src="<?php echo get_template_directory_uri(); ?>/Execel_cert.png" class="cert-item" alt="Excel Cert">
                <img src="<?php echo get_template_directory_uri(); ?>/Cyber_cert.png" class="cert-item" alt="Cyber Cert">
                <img src="<?php echo get_template_directory_uri(); ?>/Data_cert.jpg" class="cert-item" alt="Data Cert">
                <img src="<?php echo get_template_directory_uri(); ?>/Analytics_cert.jpg" class="cert-item" alt="Analytics Cert">
                
                <img src="<?php echo get_template_directory_uri(); ?>/Execel_cert.png" class="cert-item" alt="Excel Cert">
                <img src="<?php echo get_template_directory_uri(); ?>/Cyber_cert.png" class="cert-item" alt="Cyber Cert">
                <img src="<?php echo get_template_directory_uri(); ?>/Data_cert.jpg" class="cert-item" alt="Data Cert">
                <img src="<?php echo get_template_directory_uri(); ?>/Analytics_cert.jpg" class="cert-item" alt="Analytics Cert">
            </div>
        </div>
    </div>

</div>

<?php get_footer(); ?>