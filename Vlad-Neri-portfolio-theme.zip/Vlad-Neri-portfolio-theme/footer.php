<nav class="floating-dock">
        <a href="<?php echo site_url('/projects'); ?>" class="dock-item <?php echo is_page('projects') ? 'active' : ''; ?>">
           <i class="fa-regular fa-folder"></i>
        </a>
        <a href="<?php echo site_url('/about'); ?>" class="dock-item <?php echo is_page('about') ? 'active' : ''; ?>">
           <i class="fa-regular fa-user"></i>
        </a>
        <a href="<?php echo home_url(); ?>" class="dock-item <?php echo is_front_page() ? 'active' : ''; ?>">
           <i class="fa-solid fa-house"></i>
        </a>
        <a href="<?php echo site_url('/work'); ?>" class="dock-item <?php echo is_page('work') ? 'active' : ''; ?>">
           <i class="fa-solid fa-briefcase"></i>
        </a>
        <a href="<?php echo site_url('/contact'); ?>" class="dock-item <?php echo is_page('contact') ? 'active' : ''; ?>">
           <i class="fa-regular fa-paper-plane"></i>
        </a>
    </nav>

    <div id="chat-open-trigger" class="chat-open-trigger">
        <i class="fa-solid fa-message"></i>
    </div>

    <div id="vlad-gpt-main" class="vlad-gpt-container">
        
        <div class="chat-expandable-area">
            
            <div class="chat-controls-header">
                <div class="chat-status">
                    <span class="status-dot"></span>
                    <span class="chat-label">VladGPT Online</span>
                </div>
                <button id="minimize-chat" class="minimize-btn" aria-label="Close">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div id="chat-history" class="chat-history"></div>
            <div id="chat-suggestions" class="suggestions-container"></div>
        </div>

        <div class="chat-input-area">
            <span class="text">VladGPT</span>
            <div class="input-wrapper">
                <input type="text" id="user-input" placeholder="Ask about my projects..." autocomplete="off">
                <button id="send-btn" class="send-icon">
                    <i class="fa-solid fa-location-arrow"></i>
                </button>
            </div>
        </div>

    </div>
    <!-- THE EASTER EGG GAME MODAL -->
<div id="game-modal" class="game-modal-overlay">
    <div class="game-modal-content">
        <button id="close-game" class="close-btn">&times;</button>
        <div class="game-header">
            <h2>2048</h2>
            <div class="score-box">Score: <span id="game-score">0</span></div>
        </div>
        <div class="game-grid" id="game-grid">
            <!-- JS will generate the 16 cells here -->
        </div>
        <div class="game-controls">
            <p class="desktop-hint">Use <strong>Arrow Keys</strong> or buttons below</p>
            <div class="d-pad">
                <div class="space"></div>
                <button class="dir-btn" data-dir="up"><i class="fa-solid fa-arrow-up"></i></button>
                <div class="space"></div>
                <button class="dir-btn" data-dir="left"><i class="fa-solid fa-arrow-left"></i></button>
                <button class="dir-btn" data-dir="down"><i class="fa-solid fa-arrow-down"></i></button>
                <button class="dir-btn" data-dir="right"><i class="fa-solid fa-arrow-right"></i></button>
            </div>
            <button id="reset-game" class="void-btn" style="margin-top: 20px;">New Game</button>
        </div>
    </div>
</div>

    </main> <?php wp_footer(); ?>
    
</body>
</html>