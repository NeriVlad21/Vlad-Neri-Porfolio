<?php /* Template Name: Project: Life Flow */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <a href="<?php echo site_url('/projects'); ?>" class="back-link">
        <i class="fa-solid fa-chevron-left"></i> Back to Projects
    </a>

    <div class="project-hero gradient-red">
        <div class="hero-icon">
            <i class="fa-solid fa-heart-pulse"></i>
        </div>
        <div class="hero-text">
            <h1>Life Flow</h1>
            <p>Blood Donation Website to facilitate donor registration and helping those in need.</p>
        </div>
    </div>

    <div class="project-meta-grid">
        <div class="meta-column">
            <h3>About</h3>
            <p>Life Flow addresses the critical need for accessible blood donation information. It connects donors with recipients and streamlines the registration process for blood donation events.</p>
        </div>
        <div class="meta-column">
            <h3>Info</h3>
            <ul class="info-list">
                <li><i class="fa-regular fa-calendar"></i> 2025</li>
                <li><i class="fa-solid fa-user-tag"></i> Role: Project Manager & Full Stack</li>
                <li><i class="fa-solid fa-layer-group"></i> Web Application</li>
                <li>
                    <i class="fa-brands fa-github"></i> 
                    <a href="https://github.com/ikovlad/Life-Flow" target="_blank" style="color: inherit; text-decoration: underline; transition: 0.3s;">View on GitHub</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="features-section">
        <h3>Key Features</h3>
        <div class="features-grid">
            <ul class="check-list">
                <li><i class="fa-regular fa-circle-check"></i> Donor Registration System</li>
                <li><i class="fa-regular fa-circle-check"></i> Blood Type Search</li>
                <li><i class="fa-regular fa-circle-check"></i> Educational Blogs</li>
                <li><i class="fa-regular fa-circle-check"></i> Event Management</li>
            </ul>
            
            <div class="tech-stack-column">
                <span class="tech-pill">PHP</span>
                <span class="tech-pill">MySQL</span>
                <span class="tech-pill">HTML5</span>
                <span class="tech-pill">CSS3</span>
                <span class="tech-pill">VS Code</span>
            </div>
        </div>
    </div>

</div>

<?php get_footer(); ?>