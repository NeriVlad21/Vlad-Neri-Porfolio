<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> data-barba="wrapper">

    <canvas id="starfield"></canvas>

    <button id="theme-toggle" type="button" class="pull-chain theme-toggle-btn" aria-label="Toggle light and dark mode" aria-pressed="false" title="Toggle light / dark mode">
        <span class="chain-string"></span>
        <span class="chain-handle"></span>
    </button>

    <?php if ( !is_front_page() ) : ?>
    <nav class="side-dock">
        <a href="<?php echo site_url('/projects'); ?>" aria-label="Projects" class="<?php echo is_page('projects') ? 'active' : ''; ?>">
            <i class="fa-regular fa-folder"></i>
        </a>
        <a href="<?php echo site_url('/about'); ?>" aria-label="About" class="<?php echo is_page('about') ? 'active' : ''; ?>">
            <i class="fa-regular fa-user"></i>
        </a>
        <a href="<?php echo home_url(); ?>" aria-label="Home">
            <i class="fa-solid fa-house"></i>
        </a>
        <a href="<?php echo site_url('/work'); ?>" aria-label="Work" class="<?php echo is_page('work') ? 'active' : ''; ?>">
            <i class="fa-solid fa-briefcase"></i>
        </a>
        <a href="<?php echo site_url('/contact'); ?>" aria-label="Contact" class="<?php echo is_page('contact') ? 'active' : ''; ?>">
            <div class="nav-icon-circle">
                <i class="fa-regular fa-paper-plane"></i>
            </div>
        </a>
    </nav>
    <?php endif; ?>

    <main data-barba="container" data-barba-namespace="default">

        <header class="profile-header">
            <h1 class="name-title">Vlad Neri</h1>
            <p class="role-subtitle">3rd Yr. Com Sci Student | Aspiring Data Analyst</p>
        </header>