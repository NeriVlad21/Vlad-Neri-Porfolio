<nav class="floating-dock">
        <a href="<?php echo site_url('/projects'); ?>" class="dock-item <?php echo is_page('projects') ? 'active' : ''; ?>">
           <i class="fa-regular fa-folder"></i>
        </a>
        <a href="<?php echo site_url('/about'); ?>" class="dock-item <?php echo is_page('about') ? 'active' : ''; ?>">
           <i class="fa-regular fa-user"></i>
        </a>
        <a href="<?php echo home_url(); ?>" class="dock-item <?php echo is_front_page() ? 'active' : ''; ?>">
           <i class="fa-solid fa-house"></i>
        </a>
        <a href="<?php echo site_url('/work'); ?>" class="dock-item <?php echo is_page('work') ? 'active' : ''; ?>">
           <i class="fa-solid fa-briefcase"></i>
        </a>
        <a href="<?php echo site_url('/contact'); ?>" class="dock-item <?php echo is_page('contact') ? 'active' : ''; ?>">
           <i class="fa-regular fa-paper-plane"></i>
        </a>
    </nav>

    <div id="chat-open-trigger" class="chat-open-trigger">
        <i class="fa-solid fa-message"></i>
    </div>

    <div id="vlad-gpt-main" class="vlad-gpt-container">
        
        <div class="chat-expandable-area">
            
            <div class="chat-controls-header">
                <div class="chat-status">
                    <span class="status-dot"></span>
                    <span class="chat-label">VladGPT Online</span>
                </div>
                <button id="minimize-chat" class="minimize-btn" aria-label="Close">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div id="chat-history" class="chat-history"></div>
            <div id="chat-suggestions" class="suggestions-container"></div>
        </div>

        <div class="chat-input-area">
            <span class="text">VladGPT</span>
            <div class="input-wrapper">
                <input type="text" id="user-input" placeholder="Ask about my projects..." autocomplete="off">
                <button id="send-btn" class="send-icon">
                    <i class="fa-solid fa-location-arrow"></i>
                </button>
            </div>
        </div>

    </div>

    </main> <?php wp_footer(); ?>
</body>
</html>