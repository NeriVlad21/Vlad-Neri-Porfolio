<?php get_header(); ?>

<div class="mobile-container page-layout" style="padding-top: 20px;">
    
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        
        <h2 class="section-title"><?php the_title(); ?></h2>
        
        <div class="text-content">
            <?php the_content(); ?>
        </div>

    <?php endwhile; endif; ?>

</div>

<?php get_footer(); ?>