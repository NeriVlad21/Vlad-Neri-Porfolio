<?php /* Template Name: Work Page */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <h2 class="section-title animate-up">Work Experience</h2>

    <div class="work-entry animate-up">
        <div class="tech-pill" style="border-color: var(--accent-green); color: var(--accent-green); margin-bottom: 10px;">
            <i class="fa-solid fa-robot"></i> Remotasks
        </div>
        
        <h3 class="job-role">Data Annotation Specialist | July 2025 - Present</h3>
        <p class="role-meta"><em>Part-Time Position</em></p>
        
        <ul class="check-list">
            <li><i class="fa-solid fa-check" style="color: var(--accent-green);"></i> Labeling 2D & 3D visual data for autonomous vehicles.</li>
            <li><i class="fa-solid fa-check" style="color: var(--accent-green);"></i> Ensuring precise object recognition for AI training.</li>
            <li><i class="fa-solid fa-check" style="color: var(--accent-green);"></i> Maintaining high accuracy across large datasets.</li>
        </ul>
    </div>

    <hr style="border: 0; border-top: 1px solid var(--card-border); margin: 30px 0;">

    <div class="work-entry animate-up">
        <div class="tech-pill" style="border-color: var(--accent-blue); color: var(--accent-blue); margin-bottom: 10px;">
            <i class="fa-solid fa-hashtag"></i> Freelance
        </div>
        
        <h3 class="job-role">Social Media Manager | July 2023 - Present</h3>
        <p class="role-meta"><em>Contractual / Summer Role</em></p>
        
        <ul class="check-list">
            <li><i class="fa-solid fa-check" style="color: var(--accent-blue);"></i> Strategy for <strong>Kent Bryan Gapuz</strong> (1.3M+ Followers).</li>
            <li><i class="fa-solid fa-check" style="color: var(--accent-blue);"></i> Managing <strong>TenthTide Vibes</strong> (118K+ Subscribers).</li>
            <li><i class="fa-solid fa-check" style="color: var(--accent-blue);"></i> Video editing and optimizing posts for maximum reach.</li>
            <li><i class="fa-solid fa-check" style="color: var(--accent-blue);"></i> Analyzing Meta & YouTube analytics to drive growth.</li>
        </ul>

        <div class="cert-section animate-up" style="margin-top: 50px; padding-bottom: 40px;">
            <p style="margin-bottom: 20px; font-weight: 700; color: var(--accent-gold); font-size: 1.1rem; text-transform: uppercase; letter-spacing: 1px;">
                <i class="fa-solid fa-play-circle"></i> Portfolio Highlights
            </p>
            
            <div class="cert-gallery-container social-gallery-container">
                <div class="cert-track social-track">
                    
                    <a href="https://web.facebook.com/reel/1531456728114455" target="_blank" class="social-card fb-card">
                        <i class="fa-brands fa-facebook-f social-icon-large"></i>
                        <span class="social-label">Viral Reel 1</span>
                    </a>

                    <a href="https://web.facebook.com/reel/706659569089717" target="_blank" class="social-card fb-card">
                        <i class="fa-brands fa-facebook-f social-icon-large"></i>
                        <span class="social-label">Viral Reel 2</span>
                    </a>
                    
                    <a href="https://youtu.be/63yfp8V9l84?si=ATWlIsnlColApwdu" target="_blank" class="social-card yt-card">
                        <i class="fa-brands fa-youtube social-icon-large"></i>
                        <span class="social-label">TenthTide Edit</span>
                    </a>
                    
                    <a href="https://youtu.be/2rA5Pei5LsQ?si=RrSOH0sXJrtjq135" target="_blank" class="social-card yt-card">
                        <i class="fa-brands fa-youtube social-icon-large"></i>
                        <span class="social-label">Vlog Edit</span>
                    </a>

                    <a href="https://web.facebook.com/reel/1531456728114455" target="_blank" class="social-card fb-card">
                        <i class="fa-brands fa-facebook-f social-icon-large"></i>
                        <span class="social-label">Viral Reel 1</span>
                    </a>

                    <a href="https://web.facebook.com/reel/706659569089717" target="_blank" class="social-card fb-card">
                        <i class="fa-brands fa-facebook-f social-icon-large"></i>
                        <span class="social-label">Viral Reel 2</span>
                    </a>
                    
                    <a href="https://youtu.be/63yfp8V9l84?si=ATWlIsnlColApwdu" target="_blank" class="social-card yt-card">
                        <i class="fa-brands fa-youtube social-icon-large"></i>
                        <span class="social-label">TenthTide Edit</span>
                    </a>
                    
                    <a href="https://youtu.be/2rA5Pei5LsQ?si=RrSOH0sXJrtjq135" target="_blank" class="social-card yt-card">
                        <i class="fa-brands fa-youtube social-icon-large"></i>
                        <span class="social-label">Lyric Video Edit</span>
                    </a>

                </div>
            </div>
        </div>
        </div> 

</div>

<?php get_footer(); ?>