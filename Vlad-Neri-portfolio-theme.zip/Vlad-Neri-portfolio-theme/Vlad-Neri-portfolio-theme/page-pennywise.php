<?php /* Template Name: Project: PennyWise */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <a href="<?php echo site_url('/projects'); ?>" class="back-link">
        <i class="fa-solid fa-chevron-left"></i> Back to Projects
    </a>

    <div class="project-hero gradient-green">
        <div class="hero-icon">
            <i class="fa-solid fa-sack-dollar"></i>
        </div>
        <div class="hero-text">
            <h1>PennyWise</h1>
            <p>A financial literacy app to gain knowledge and manage saving goals.</p>
        </div>
    </div>

    <div class="project-meta-grid">
        <div class="meta-column">
            <h3>About</h3>
            <p>PennyWise helps students and young adults calculate future value, plan finances, and manage saving goals with ease. It features a modern Android UI.</p>
        </div>
        <div class="meta-column">
            <h3>Info</h3>
            <ul class="info-list">
                <li><i class="fa-regular fa-calendar"></i> 2025</li>
                <li><i class="fa-solid fa-user-tag"></i> Role: PM & UI Designer</li>
                <li><i class="fa-brands fa-android"></i> Android App</li>
            </ul>
        </div>
    </div>

    <div class="features-section">
        <h3>Key Features</h3>
        <div class="features-grid">
            <ul class="check-list">
                <li><i class="fa-regular fa-circle-check"></i> Future Value Calculator</li>
                <li><i class="fa-regular fa-circle-check"></i> Savings Goal Tracker</li>
                <li><i class="fa-regular fa-circle-check"></i> Transaction History</li>
                <li><i class="fa-regular fa-circle-check"></i> Financial Tips</li>
                <li>
                    <i class="fa-brands fa-github"></i> 
                    <a href="https://github.com/fpaulpalis/PennyWise-GreenStash/" target="_blank" style="color: inherit; text-decoration: underline; transition: 0.3s;">View on GitHub</a>
                </li>
            </ul>
            
            <div class="tech-stack-column">
                <span class="tech-pill">Kotlin</span>
                <span class="tech-pill">Jetpack Compose</span>
                <span class="tech-pill">Firebase</span>
                <span class="tech-pill">Android Studio</span>
            </div>
        </div>
    </div>

</div>

<?php get_footer(); ?>