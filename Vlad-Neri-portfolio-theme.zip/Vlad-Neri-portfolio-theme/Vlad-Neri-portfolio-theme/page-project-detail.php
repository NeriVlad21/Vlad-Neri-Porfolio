<?php /* Template Name: Project Detail Template */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <a href="<?php echo site_url('/projects'); ?>" class="back-link">
        <i class="fa-solid fa-chevron-left"></i> Back to Projects
    </a>

    <div class="project-hero gradient-gold">
        <div class="hero-icon">
            <span style="font-size: 2.5rem; font-weight: 800; font-family: cursive;">SCRAAATCH</span>
        </div>
        <div class="hero-text">
            <h1>Scraaatch</h1>
            <p>Create and send custom scratch cards to your family and friends.</p>
        </div>
    </div>

    <div class="project-meta-grid">
        <div class="meta-column">
            <h3>About</h3>
            <p>An innovative web application that allows users to design personalized scratch cards for various occasions.</p>
        </div>
        <div class="meta-column">
            <h3>Info</h3>
            <ul class="info-list">
                <li><i class="fa-solid fa-link"></i> <a href="#">scraaatch.com</a></li>
                <li><i class="fa-regular fa-calendar"></i> 2022</li>
                <li><i class="fa-solid fa-users"></i> 1.2k+ Users</li>
            </ul>
        </div>
    </div>

    <div class="features-section">
        <h3>Key Features</h3>
        <div class="features-grid">
            <ul class="check-list">
                <li><i class="fa-regular fa-circle-check"></i> Customisable designs</li>
                <li><i class="fa-regular fa-circle-check"></i> Personalised messages</li>
                <li><i class="fa-regular fa-circle-check"></i> Digital delivery</li>
                <li><i class="fa-regular fa-circle-check"></i> WYSIWYG editor</li>
            </ul>
            
            <div class="tech-stack-column">
                <span class="tech-pill"><i class="fa-brands fa-react"></i> Next.js</span>
                <span class="tech-pill"><i class="fa-brands fa-js"></i> TypeScript</span>
                <span class="tech-pill">Mantine</span>
                <span class="tech-pill">Supabase</span>
            </div>
        </div>
    </div>

    <div class="more-projects">
        <h3>More Projects</h3>
        <div class="mini-project-grid">
            <a href="#" class="mini-card gradient-purple">
                <i class="fa-solid fa-horse-head"></i>
            </a>
            <a href="#" class="mini-card gradient-green">
                <i class="fa-solid fa-pen-nib"></i>
            </a>
            <a href="#" class="mini-card gradient-red">
                <i class="fa-solid fa-code"></i>
            </a>
        </div>
    </div>

</div>

<?php get_footer(); ?>