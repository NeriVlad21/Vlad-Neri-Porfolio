<?php /* Template Name: Project: Manga Haven */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <a href="<?php echo site_url('/projects'); ?>" class="back-link">
        <i class="fa-solid fa-chevron-left"></i> Back to Projects
    </a>

    <div class="project-hero gradient-purple">
        <div class="hero-icon">
            <i class="fa-solid fa-book-open"></i>
        </div>
        <div class="hero-text">
            <h1>Manga Haven PH</h1>
            <p>Rental Bookstore Management System with comprehensive dashboard analytics.</p>
        </div>
    </div>

    <div class="project-meta-grid">
        <div class="meta-column">
            <h3>About</h3>
            <p>A management system designed for rental bookstores. It tracks inventory, rental status, penalties, and employee performance through a centralized dashboard.</p>
        </div>
        <div class="meta-column">
            <h3>Info</h3>
            <ul class="info-list">
                <li><i class="fa-regular fa-calendar"></i> 2025</li>
                <li><i class="fa-solid fa-user-tag"></i> Role: Full Stack & PM</li>
                <li><i class="fa-solid fa-chart-line"></i> Dashboard System</li>
                <li>
                    <i class="fa-brands fa-github"></i> 
                    <a href="https://github.com/ikovlad/mangahavenph" target="_blank" style="color: inherit; text-decoration: underline; transition: 0.3s;">View on GitHub</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="features-section">
        <h3>Key Features</h3>
        <div class="features-grid">
            <ul class="check-list">
                <li><i class="fa-regular fa-circle-check"></i> Admin Dashboard</li>
                <li><i class="fa-regular fa-circle-check"></i> Rental Tracking</li>
                <li><i class="fa-regular fa-circle-check"></i> Inventory Management</li>
                <li><i class="fa-regular fa-circle-check"></i> Employee/Customer DB</li>
            </ul>
            
            <div class="tech-stack-column">
                <span class="tech-pill">PHP</span>
                <span class="tech-pill">SQL</span>
                <span class="tech-pill">HTML5</span>
                <span class="tech-pill">CSS3</span>
            </div>
        </div>
    </div>

</div>

<?php get_footer(); ?>