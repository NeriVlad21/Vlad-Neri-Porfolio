<?php 
/* Template Name: Contact Page */ 
get_header(); 
?>

<style>
.contact-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
    padding-top: 50px; 
    margin-bottom: 60px;
}

@media (max-width: 768px) {
    .contact-grid {
        grid-template-columns: 1fr;
        gap: 60px; 
    }
}

.void-contact-card {
    background: rgba(12, 12, 12, 0.6);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 20px;
    padding: 50px 25px 30px;
    position: relative;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    box-shadow: 0 15px 35px rgba(0,0,0,0.5), inset 0 1px 1px rgba(255,255,255,0.05);
    transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), border-color 0.4s ease;
}

.void-contact-card:hover {
    transform: translateY(-10px);
    border-color: rgba(255, 255, 255, 0.15);
    background: rgba(20, 20, 20, 0.8);
}

.floating-icon-circle {
    position: absolute;
    top: -35px;
    left: 50%;
    transform: translateX(-50%);
    width: 70px;
    height: 70px;
    border-radius: 50%;
    background: #080808; 
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    color: white;
    border: 2px solid rgba(255, 255, 255, 0.1);
    box-shadow: 0 10px 20px rgba(0,0,0,0.6);
    transition: all 0.4s ease;
}

.void-contact-card:hover .floating-icon-circle {
    transform: translateX(-50%) translateY(-5px) scale(1.1);
}

.gold-glow { color: var(--accent-gold); }
.void-contact-card:hover .gold-glow { border-color: var(--accent-gold); box-shadow: 0 0 25px rgba(226, 220, 200, 0.4), inset 0 0 10px rgba(226, 220, 200, 0.2); }

.blue-glow { color: var(--accent-blue); }
.void-contact-card:hover .blue-glow { border-color: var(--accent-blue); box-shadow: 0 0 25px rgba(30, 144, 255, 0.4), inset 0 0 10px rgba(30, 144, 255, 0.2); }

.purple-glow { color: var(--accent-purple); }
.void-contact-card:hover .purple-glow { border-color: var(--accent-purple); box-shadow: 0 0 25px rgba(155, 89, 182, 0.4), inset 0 0 10px rgba(155, 89, 182, 0.2); }

.void-contact-card h3 {
    font-size: 1.5rem;
    color: white;
    margin: 0 0 15px 0;
    font-weight: 700;
}

.void-contact-card p {
    font-size: 0.95rem;
    color: var(--text-muted);
    margin-bottom: 25px;
    line-height: 1.6;
    flex-grow: 1; 
}

.contact-text-link {
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--accent-gold);
    text-decoration: none;
    letter-spacing: 1px;
    transition: color 0.3s, text-shadow 0.3s;
    margin-top: auto;
}
.contact-text-link:hover { color: white; text-shadow: 0 0 15px rgba(255,255,255,0.4); }

.void-btn {
    display: inline-flex;
    width: 100%;
    align-items: center;
    justify-content: center;
    padding: 14px 20px;
    border-radius: 12px;
    font-size: 0.95rem;
    font-weight: 700;
    text-transform: uppercase;
    text-decoration: none;
    letter-spacing: 1px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    margin-top: auto;
}

.void-btn::after {
    content: ''; position: absolute; top: 0; left: -100%; width: 50%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transform: skewX(-20deg); transition: left 0.5s ease; z-index: 1;
}
.void-btn:hover::after { left: 150%; }

.blue-btn { background: #1e90ff; color: white; border: 1px solid #1e90ff; box-shadow: 0 5px 15px rgba(30, 144, 255, 0.2); }
.blue-btn:hover { background: #0073e6; box-shadow: 0 10px 25px rgba(30, 144, 255, 0.5); transform: translateY(-3px); }

.white-btn { background: white; color: black; border: 1px solid white; box-shadow: 0 5px 15px rgba(255,255,255,0.1); }
.white-btn:hover { background: #e0e0e0; box-shadow: 0 10px 25px rgba(255, 255, 255, 0.3); transform: translateY(-3px); }
</style>

<div class="mobile-container page-layout">
    
    <div class="contact-header animate-up">
        <h2 class="section-title">Get in Touch</h2>
        <p style="color: var(--text-muted); text-align: center; margin-bottom: 70px;">
            Have a project in mind or just want to say hi? <br> Choose how you want to connect below.
        </p>
    </div>

    <div class="contact-grid animate-up">
        
        <div class="void-contact-card">
            <div class="floating-icon-circle gold-glow">
                <i class="fa-solid fa-phone"></i>
            </div>
            <h3>Call Us</h3>
            <p>Available for urgent inquiries or quick questions regarding projects.</p>
            <a href="tel:+639454998054" class="contact-text-link">0945-499-8054</a>
        </div>

        <div class="void-contact-card">
            <div class="floating-icon-circle blue-glow">
                <i class="fa-solid fa-comment-dots"></i>
            </div>
            <h3>Chat Live</h3>
            <p>Prefer a quick chat? Send me a direct message on Messenger anytime.</p>
            <a href="https://m.me/vlad.neri.1238" target="_blank" class="void-btn blue-btn">Chat Now</a>
        </div>

        <div class="void-contact-card">
            <div class="floating-icon-circle purple-glow">
                <i class="fa-solid fa-envelope"></i>
            </div>
            <h3>Ask a Question</h3>
            <p>Send me your project details and I'll get back to you within 24 hours.</p>
            <a href="mailto:mereziko@gmail.com" class="void-btn white-btn">Email Me</a>
        </div>

    </div>

    <div class="contact-socials animate-up" style="display: flex; justify-content: center; gap: 20px; margin-top: 60px;">
        <a href="https://web.facebook.com/vlad.neri.1238/" target="_blank" class="social-btn facebook" aria-label="Facebook">
            <i class="fa-brands fa-facebook-f"></i>
        </a>
        <a href="https://www.linkedin.com/in/vladneri/" target="_blank" class="social-btn linkedin" aria-label="LinkedIn">
            <i class="fa-brands fa-linkedin-in"></i>
        </a>
        <a href="https://github.com/ikovlad" target="_blank" class="social-btn github" aria-label="GitHub">
            <i class="fa-brands fa-github"></i>
        </a>
    </div>

</div>

<?php get_footer(); ?>