document.addEventListener('DOMContentLoaded', () => {
    console.log("VladGPT System: Online");

    // ==========================================
    // 1. THEME TOGGLE (FIXED & MERGED)
    // ==========================================
    const body = document.body;
    // We use .pull-chain because that is what is in your CSS
    const chain = document.querySelector('.pull-chain'); 

    // A. Check for saved preference immediately on load
    if (localStorage.getItem("theme") === "light") {
        body.classList.add("light-mode");
    }

    // B. The Click Event (Animation + Toggle + Save)
    if(chain) {
        chain.addEventListener('click', (e) => {
            e.preventDefault();
            
            // 1. Visual Animation (Pull effect)
            chain.style.transform = "translateY(20px)";
            setTimeout(() => chain.style.transform = "translateY(0)", 200);
            
            // 2. Toggle the class
            body.classList.toggle('light-mode');
            
            // 3. Save preference to memory
            if (body.classList.contains("light-mode")) {
                localStorage.setItem("theme", "light");
                console.log("Mode: Light");
            } else {
                localStorage.setItem("theme", "dark");
                console.log("Mode: Dark");
            }
        });
    } else {
        console.error("Error: .pull-chain element not found. Check your HTML.");
    }

    // ==========================================
    // 2. STARFIELD ANIMATION
    // ==========================================
    const canvas = document.getElementById('starfield');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let width, height, stars = [];

        function initStars() {
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = width;
            canvas.height = height;
            stars = [];
            for (let i = 0; i < 100; i++) {
                stars.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    size: Math.random() * 2,
                    speed: Math.random() * 0.5 + 0.1
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, width, height);
            const isLight = document.body.classList.contains('light-mode');
            ctx.fillStyle = isLight ? "rgba(0, 0, 0, 0.5)" : "rgba(255, 255, 255, 0.8)";
            
            stars.forEach(star => {
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
                ctx.fill();
                star.y -= star.speed;
                if (star.y < 0) {
                    star.y = height;
                    star.x = Math.random() * width;
                }
            });
            requestAnimationFrame(drawStars);
        }

        window.addEventListener('resize', initStars);
        initStars();
        drawStars();
    }

    // ==========================================
    // 3. MIKAELGPT (The Massive Brain - V3.0 FINAL)
    // ==========================================
    const database = [
        // =================================================================
        // 1. DEEP DIVE: IDENTITY & BIO (14 Entries)
        // =================================================================
        { 
            keys: ["who are you", "who is vlad", "who is mikael", "identify", "intro", "introduction", "bio", "profile", "summary", "background", "about you", "tell me about yourself", "vlad", "mikael", "val", "identity"], 
            resp: "I am Mikael Vladimir M. Neri, a 20-year-old BS Computer Science student and disciplined Full Stack Developer based in La Union, Philippines. I balance academic rigor with professional work in Data Annotation and Social Media Management. <br><br>Read my full story on the <a href='/about' class='chat-link'>About Page</a>." 
        },
        { 
            keys: ["full name", "complete name", "real name", "name", "what is your name", "call you", "nickname", "alias", "names", "preferred name"], 
            resp: "My full legal name is Mikael Vladimir M. Neri. You can refer to me simply as Vlad." 
        },
        { 
            keys: ["age", "how old", "birth year", "birthday", "date of birth", "when were you born", "birthdate", "year of birth", "turning"], 
            resp: "I am currently 20 years old**, born in the year 2005." 
        },
        { 
            keys: ["location", "where do you live", "address", "based", "city", "province", "region", "hometown", "from where", "country", "residence", "staying", "la union", "rosario"], 
            resp: "I am based in Brgy. Tabtabungao, Rosario, La Union, Philippines (Zip Code: 2506). I am fully equipped for remote work environments." 
        },
        { 
            keys: ["nationality", "citizen", "citizenship", "filipino", "pinoy", "race", "ethnicity"], 
            resp: "I am proudly **Filipino**." 
        },
        { 
            keys: ["gender", "sex", "male", "man", "pronouns"], 
            resp: "I am Male." 
        },
        { 
            keys: ["status", "relationship", "single", "taken", "girlfriend", "gf", "partner", "love life", "married", "dating", "committed"], 
            resp: "I am in a committed long-distance relationship that has been strong for almost 3 years. We celebrate monthly anniversaries and prioritize communication." 
        },
        { 
            keys: ["ldr", "long distance", "partner location", "meetup", "future plans relationship"], 
            resp: "My partner lives in the US. Despite the distance, we make it work, and we are actively planning our first meetup in **2026**." 
        },
        { 
            keys: ["height", "how tall", "stature", "centimeters", "feet", "standing", "tall", "height stats", "metrics"], 
            resp: "I stand at exactly 5'6 3/4\". (Don't forget the 3/4, it counts!)." 
        },
        { 
            keys: ["weight", "current weight", "body weight", "mass", "kg", "kilograms", "heavy"], 
            resp: "I cannot answer that." 
        },
        { 
            keys: ["fitness goal", "gym", "weight loss", "diet plan", "target weight", "losing weight", "health goal", "omad", "fasting"], 
            resp: "I am on a disciplined weight loss journey using an OMAD (One Meal A Day) protocol and boxing training." 
        },
        { 
            keys: ["bmi", "body mass index", "health stats", "obese", "overweight"], 
            resp: "My current BMI is 40.97. This number is my motivation to work harder on my health goals." 
        },
        { 
            keys: ["family", "parents", "guardian", "living with", "lola", "grandmother", "household", "living situation", "who do you live with"], 
            resp: "I live with my Lola (Grandmother), who is my legal guardian. I take responsibility for assisting her with daily tasks and managing technical aspects of our household. I also live in other house when I'm needed." 
        },
        { 
            keys: ["future goals", "life goals", "plans", "where do you see yourself", "aspirations", "civil service", "travel plans", "leyte"], 
            resp: "Besides my tech career, my near-term goals include passing the **Civil Service Exam** in March 2026 and a planned trip to **Baybay City, Leyte** in May 2026." 
        },

        // =================================================================
        // 2. DEEP DIVE: ACADEMICS (12 Entries)
        // =================================================================
        { 
            keys: ["education", "university", "school", "college", "degree", "course", "study", "academic", "student", "upang", "phinma", "alma mater", "what do you study"], 
            resp: "I am pursuing a Bachelor of Science in Computer Science (BSCS) at PHINMA University of Pangasinan - Urdaneta (UPang)." 
        },
        { 
            keys: ["year level", "what year", "grade", "classification", "batch", "class of"], 
            resp: "I am currently a 3rd Year student, expected to graduate with the Class of 2027." 
        },
        { 
            keys: ["section", "block", "class section", "class schedule"], 
            resp: "I belong to section BSCS3-01." 
        },
        { 
            keys: ["academic performance", "grades", "honors", "achievements", "shs", "high school", "smart"], 
            resp: "I am a consistent academic performer in university. I previously graduated Senior High School with Honors." 
        },
        { 
            keys: ["thesis", "capstone", "research", "proposal", "project study", "final project", "research paper", "study", "defense", "cos 008", "current subject"], 
            resp: "I am currently focused on Thesis Research. With my team, our focus right now is researching about an app we will call as 'F.L.A.M.E.S.' " 
        },
     
        { 
            keys: ["student id", "id number", "school id"], 
            resp: "That information is confidential!" 
        },

        // =================================================================
        // 3. DEEP DIVE: TECH STACK & SKILLS (15 Entries)
        // =================================================================
        { 
            keys: ["stack", "tech stack", "technologies", "technology", "languages", "programming languages", "coding languages", "what do you use", "tools", "software", "tech", "skills", "abilities", "arsenal"], 
            resp: "I am a Aspiring Data Analyst. Currently, my skills & toolkit includes:\n• Backend: PHP, Python, Java, SQL\n• Mobile: Kotlin (Android)\n• Frontend: HTML, CSS, JavaScript\n• Tools: VS Code, Android Studio, Figma, Git, Linux.\n<br>See the visual breakdown on my <a href='/about' class='chat-link'>About Page</a>." 
        },
        { 
            keys: ["specialty", "specialize", "expertise", "expert in", "focus", "niche", "strength", "what are you good at", "main skill"], 
            resp: "My primary expertise lies in Backend Web Development (PHP/MySQL) and Native Android Development (Kotlin). I also have a professional niche in AI Data Annotation (LiDAR)." 
        },
        { 
            keys: ["php", "laravel", "backend", "server side", "php developer", "php skills", "backend dev", "scripting language"], 
            resp: "PHP is my core backend language. I use it to build dynamic, secure, database-driven web applications like Life Flow and Moya without relying heavily on frameworks." 
        },
        { 
            keys: ["kotlin", "android", "mobile app", "native dev", "app development", "mobile skills", "android dev", "mobile developer", "apk", "android studio"], 
            resp: "I use Kotlin within Android Studio to build robust, native Android applications. I handle everything from XML UI design to complex backend logic, as seen in my PennyWise app." 
        },
        { 
            keys: ["python", "py", "python skills", "automation", "data analysis", "scripting", "backend python", "snake language"], 
            resp: "I utilize Python for backend scripting, data automation tasks, and algorithmic problem-solving. It plays a key role in my data analysis aspirations." 
        },
        { 
            keys: ["java", "oop", "java skills", "object oriented", "java programming"], 
            resp: "I am proficient in Java, which provides my strong foundation in Object-Oriented Programming (OOP) principles like inheritance and polymorphism." 
        },
        { 
            keys: ["javascript", "js", "frontend js", "es6", "vanilla js", "interactive", "web logic", "script"], 
            resp: "I use Vanilla JavaScript (ES6+) to create interactive front-end experiences. I prefer writing clean, dependency-free code for performance (like the engine running this chatbot!)." 
        },
        { 
            keys: ["sql", "mysql", "database", "db", "query", "data management", "relational database", "backend data", "sql skills"], 
            resp: "I design and manage relational databases using MySQL. I write complex SQL queries to efficiently store, retrieve, and manage data for my web applications." 
        },
        { 
            keys: ["html", "css", "html5", "css3", "web design", "frontend design", "responsive design", "styling"], 
            resp: "I write semantic HTML5 for structure and use modern CSS3 (Flexbox, Grid, custom properties) to create responsive, visually appealing web designs." 
        },
        { 
            keys: ["figma", "ui", "ux", "design", "prototyping", "wireframing", "mockup", "interface", "web design tool", "user experience"], 
            resp: "Figma is my go-to tool for UI/UX design. I create high-fidelity prototypes to visualize the user journey before writing any code." 
        },
        { 
            keys: ["git", "github", "version control", "repo", "source control", "commit", "push"], 
            resp: "I use Git for version control and collaboration. You can review my public code repositories at github.com/ikovlad." 
        },
        { 
            keys: ["ide", "editor", "development environment", "vs code", "visual studio code", "android studio"], 
            resp: "My primary IDEs are Visual Studio Code for web development and scripting, and Android Studio for native mobile development." 
        },
        { 
            keys: ["os", "operating system", "windows", "linux", "ubuntu", "kali", "kali linux", "terminal"], 
            resp: "I use Windows 11 as my daily driver but am comfortable navigating Linux environments, specifically **Ubuntu** and **Kali Linux**, for development and security tasks." 
        },
        { 
            keys: ["video editing", "video editor", "davinci", "davinci resolve", "capcut", "editing skills", "premiere"], 
            resp: "I am skilled in video editing using professional software like DaVinci Resolve for color grading and complex edits, and **CapCut** for quick, trend-based social media content." 
        },
        { 
            keys: ["excel", "microsoft excel", "spreadsheet", "sheets", "data entry"], 
            resp: "I am proficient in Microsoft Excel for data organization, analysis, and reporting." 
        },

        // =================================================================
        // 4. DEEP DIVE: PROJECTS (12 Entries)
        // =================================================================
        { 
            keys: ["projects", "project", "portfolio", "work", "what have you built", "showcase", "my projects", "list projects", "apps", "websites", "gallery", "case studies"], 
            resp: "I have architected several full-stack applications. My core portfolio includes:\n1. **Life Flow** (Blood Donation)\n2. **Moya** (Water Delivery)\n3. **PennyWise** (Finance App)\n4. **Manga Haven** (Rental System)\n<br>Explore them on the <a href='/projects' class='chat-link'>Projects Page</a>." 
        },
        { 
            keys: ["life flow", "blood donation", "lifeflow", "blood app", "hospital system", "donor app", "life flow project", "php project", "health app"], 
            resp: "Life Flow is a comprehensive web platform that addresses the logistical disconnect between blood donors and hospitals. <br>**Tech Stack:** Native PHP, MySQL, HTML5, CSS3." 
        },
        { 
            keys: ["life flow features", "how life flow works"], 
            resp: "It features a secure donor registration system, a searchable blood type database for emergencies, and an event management module for donation drives." 
        },
        { 
            keys: ["moya", "water delivery", "refill the chill", "moya app", "inventory system", "logistics app", "business system", "water refilling", "moya project"], 
            resp: "Moya ('Refill the Chill') is a targeted delivery management system designed for local water stations in Rosario, La Union. <br>**Tech Stack:** PHP, MySQL, JavaScript." 
        },
        { 
            keys: ["moya features", "how moya works", "moya purpose"], 
            resp: "Moya streamlines operations by allowing businesses to track orders in real-time, optimize delivery routes, and automate inventory calculations." 
        },
        { 
            keys: ["pennywise", "finance app", "money manager", "android app", "kotlin project", "mobile dev", "savings tracker", "budget app", "pennywise project"], 
            resp: "PennyWise is a native Android application for personal finance management. <br>**Tech Stack:** 100% Kotlin in Android Studio." 
        },
        { 
            keys: ["pennywise features", "how pennywise works", "future value"], 
            resp: "It allows users to log daily expenses and visualize savings goals. It features a custom algorithm I wrote to calculate the **Future Value** of savings based on different parameters." 
        },
        { 
            keys: ["manga haven", "manga project", "bookstore", "rental system", "library system", "inventory management", "crud", "book rental", "php rental"], 
            resp: "Manga Haven PH is a robust Rental Bookstore Management System built for efficiency. <br>**Tech Stack:** PHP, MySQL." 
        },
        { 
            keys: ["manga haven features", "how manga haven works", "penalty calculation"], 
            resp: "It handles complex backend logic, including tracking inventory, managing borrower history, and automatically calculating penalty fees for overdue items." 
        },

        // =================================================================
        // 5. DEEP DIVE: WORK EXPERIENCE (15 Entries)
        // =================================================================
        { 
            keys: ["experience", "work experience", "job history", "career", "background", "professional background", "employment", "history", "jobs", "cv", "resume", "work timeline"], 
            resp: "I combine academic rigor with practical industry experience. I work simultaneously as a **Data Annotation Specialist** (AI/LiDAR) and a **Social Media Manager**. See the timeline on the <a href='/work' class='chat-link'>Work Experience Page</a>." 
        },
        { 
            keys: ["remotasks", "data annotation", "ai training", "lidar", "annotation job", "remote work", "labeling", "annotator", "ai job"], 
            resp: "I have been a **Data Annotation Specialist** at Remotasks since July 2025. My role is crucial for training machine learning models." 
        },
        { 
            keys: ["remotasks specifics", "lidar annotation", "3d annotation", "annotation accuracy", "remotasks volume", "how many tasks"], 
            resp: "I specialize in complex 3D LiDAR annotation for autonomous vehicles. I process a high volume of **70-100 tasks per week** while maintaining an exceptional **98%+ accuracy rating**." 
        },
        { 
            keys: ["smm", "social media manager", "content manager", "marketing", "facebook management", "growth", "influencer manager", "social media job"], 
            resp: "I work as a freelance **Social Media Manager** (since July 2023), handling the digital presence of high-profile influencers." 
        },
        { 
            keys: ["clients", "who do you manage", "kent bryan gapuz", "tenthtide", "vibes", "influencers managed"], 
            resp: "My key clients include Kent Bryan Gapuz (managing a following of 1.3M+) and the TenthTide Vibes YouTube channel (118K+ Subscribers)." 
        },
        { 
            keys: ["smm tasks", "what do you do as smm", "smm skills", "video editing smm", "analytics"], 
            resp: "My SMM responsibilities include content strategy, video editing (Reels/TikToks), analyzing Meta & YouTube analytics for growth, and managing copyright claims or shadowban issues." 
        },
        { 
            keys: ["freelance", "hire", "available", "rates", "contract", "job offer", "work together", "pricing", "cost", "quotation", "commission", "open for work"], 
            resp: "Yes, I am actively accepting commissions! I take on Web Development, Android App, and Data Annotation projects. Pricing is based on scope. Contact me via the <a href='/contact' class='chat-link'>Contact Form</a> for a quote." 
        },
        { 
            keys: ["services", "what do you offer", "what can you do", "capabilities", "service list", "offerings", "skills for hire"], 
            resp: "I offer:\n• Web Dev: Custom PHP/SQL sites.\n• Mobile Dev Native Kotlin Android apps.\n• AI Data Services: High-precision LiDAR/2D Annotation.\n• SMM: Content strategy & analytics." 
        },

        // =================================================================
        // 6. DEEP DIVE: HOBBIES & PERSONALITY (15 Entries)
        // =================================================================
        { 
            keys: ["hobbies", "interests", "free time", "fun", "what do you do for fun", "personal life", "outside work", "entertainment", "likes", "pastimes"], 
            resp: "I'm a passionate sports and anime fan. I closely follow the NBA (Lakers) and Boxing. To relax, I binge-watch anime or play PC games." 
        },
        { 
            keys: ["nba", "basketball", "lakers", "sports", "favorite team", "la lakers", "ball", "hoops"], 
            resp: "I am a die-hard **Los Angeles Lakers** fan. I enjoy the analytical side of basketball, breaking down team strategies and player efficiency ratings." 
        },
        { 
            keys: ["goat", "lebron", "jordan", "kobe", "nba goat debate"], 
            resp: "The GOAT debate is tough! I respect Jordan's peak dominance, but I appreciate LeBron's unprecedented longevity and all-around game." 
        },
        { 
            keys: ["boxing", "combat sports", "pacquiao", "mayweather", "fitness", "training", "workout", "tyson", "marquez", "sweet science"], 
            resp: "Boxing is my primary fitness outlet. I study the technical brilliance of legends like **Manny Pacquiao** and **Floyd Mayweather**, and I incorporate shadow boxing into my daily routine." 
        },

        { 
            keys: ["gaming", "games", "pc games", "what do you play", "gamer"], 
            resp: "I play PC games occasionally as a way to de-stress and reset my mind after long coding sessions." 
        },
        { 
            keys: ["diet", "nutrition", "omad", "fasting", "health", "eating habits", "food", "favorite food", "pizza", "meal plan"], 
            resp: "I love Pizza, but I am currently very strict with my OMAD (One Meal A Day) protocol to achieve my weight loss goals." 
        },
        { 
            keys: ["music", "songs", "playlist", "listen", "genre", "coding music"], 
            resp: "Music is essential to my workflow. I listen to a wide variety of genres to stay focused while coding." 
        },

        // =================================================================
        // 7. DEEP DIVE: CONTACT & SOCIALS (10 Entries)
        // =================================================================
        { 
            keys: ["contact", "email", "phone", "reach me", "message", "get in touch", "contact info", "number", "telephone", "mobile number", "gmail", "contact details"], 
            resp: "Let's talk! You can email me directly at mereziko@gmail.com or text/call my mobile at **0945 499 8054**." 
        },
        { 
            keys: ["contact form", "website contact", "hire button"], 
            resp: "For formal inquiries or project quotes, please use the form on the <a href='/contact' class='chat-link'>Contact Page</a> for a faster response." 
        },
        { 
            keys: ["socials", "links", "facebook", "linkedin", "github", "connect", "profiles", "social media", "online presence", "fb", "git", "where can i find you"], 
            resp: "Let's connect online:\n• **GitHub:** github.com/ikovlad\n• LinkedIn: linkedin.com/in/vladneri/\n• **Facebook:** facebook.com/vlad.neri.1238" 
        },
        { 
            keys: ["github link", "git profile", "repo link", "show me your code"], 
            resp: "Check out my code repositories at github.com/ikovlad." 
        },
        { 
            keys: ["linkedin link", "professional profile"], 
            resp: "Connect with me professionally at linkedin.com/in/vladneri/." 
        },
        { 
            keys: ["facebook link", "fb profile"], 
            resp: "You can find my personal profile at facebook.com/vlad.neri.1238." 
        },
        { 
            keys: ["response time", "when will you reply", "availability"], 
            resp: "I typically respond to professional inquiries within 24 hours." 
        },

        // =================================================================
        // 8. META & EASTER EGGS (8 Entries)
        // =================================================================
        { 
            keys: ["are you ai", "bot", "robot", "chatgpt", "gpt", "gemini", "what are you", "are you real"], 
            resp: "I am VladGPT, a custom-coded conversational interface designed to represent Vlad's professional persona. I run on pure JavaScript logic, not LLM magic!" 
        },
        { 
            keys: ["creator", "who made you", "developer", "author", "who built this site", "who coded you"], 
            resp: "I was architected and developed completely from scratch by Mikael Vladimir M. Neri." 
        },
        { 
            keys: ["tech behind bot", "how do you work", "chatbot code"], 
            resp: "I operate using a JavaScript-based heuristic matching algorithm that scans your input for keywords and retrieves the most relevant response from a local JSON database." 
        },
        { 
            keys: ["hello", "hi", "hey", "greetings", "good morning", "good afternoon", "good evening", "sup", "yo", "howdy"], 
            resp: "Hello! Welcome to my interactive portfolio. Feel free to ask me anything about Vlad's skills, projects, or experience." 
        },
        { 
            keys: ["joke", "funny", "tell me a joke", "humor", "make me laugh"], 
            resp: "Why do Java developers wear glasses? Because they don't C#!" 
        },
        { 
            keys: ["secret", "hidden", "password", "easter egg", "find something"], 
            resp: "You found a secret note! This entire portfolio is built on a custom WordPress theme developed from scratch, without using any page builders like Elementor." 
        },
        { 
            keys: ["hack", "hacker", "cybersecurity", "security", "osint", "investigation"], 
            resp: "I have knowledge of cybersecurity basics and Open Source Intelligence (OSINT), but I strictly practice ethical coding." 
        },

        // =================================================================
        // 9. FALLBACK (DEFAULT)
        // =================================================================
        { 
            keys: ["default"], 
            resp: "I apologize, but I don't have specific data on that topic in my current database. However, I can provide detailed insights into my Technical Stack, Project Portfolio, Work Experience, or Contact Details. What would you like to know?" 
        }
    ];

    // ==========================================
    // 4. CHAT INTERFACE LOGIC
    // ==========================================
    const input = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const history = document.getElementById('chat-history');
    const suggestBox = document.getElementById('chat-suggestions');
    const mainChat = document.getElementById('vlad-gpt-main');
    const minimizeBtn = document.getElementById('minimize-chat');
    const inputArea = document.querySelector('.chat-input-area'); 

    // 1. SMART SUGGESTIONS
    const suggestions = [
        { label: "Who is Vlad?", keyword: "who are you" },
        { label: "Check Skills", keyword: "skills" },
        { label: "View Projects", keyword: "projects" },
        { label: "Contact Info", keyword: "contact" }
    ];

    if(suggestBox) {
        suggestBox.innerHTML = '';
        suggestions.forEach(item => {
            const btn = document.createElement('div');
            btn.className = 'suggestion-chip';
            btn.innerText = item.label;
            btn.onclick = () => { 
                if(input) { input.value = item.label; handleChat(item.keyword); }
            };
            suggestBox.appendChild(btn);
        });
    }

    // 2. OPEN LOGIC
    if (mainChat && inputArea) {
        // OPEN: Only when hovering the INPUT BAR or Typing
        inputArea.addEventListener('mouseenter', () => {
            mainChat.classList.add('active');
        });

        if(input) {
            input.addEventListener('focus', () => {
                mainChat.classList.add('active');
            });
        }

        // CLOSE: Logic for the X button
        if (minimizeBtn) {
            minimizeBtn.addEventListener('click', (e) => {
                e.stopPropagation(); 
                e.preventDefault();
                mainChat.classList.remove('active');
                if(input) input.blur();
            });
        }
        
        // AUTO-CLOSE
        mainChat.addEventListener('mouseleave', () => {
            if (input !== document.activeElement) {
                mainChat.classList.remove('active');
            }
        });
    }

    // 3. MESSAGING LOGIC
    function handleChat(forcedKey = null) {
        if(!input) return;
        const text = input.value.trim();
        if(!text && !forcedKey) return;

        mainChat.classList.add('active');
        if(suggestBox) suggestBox.style.display = 'none';

        addMsg(text || forcedKey, 'user');
        input.value = '';

        // Thinking...
        const thinkingId = 'thinking-' + Date.now();
        const d = document.createElement('div');
        d.className = `msg bot`;
        d.id = thinkingId;
        d.innerHTML = '...';
        history.appendChild(d);
        history.scrollTop = history.scrollHeight;

        setTimeout(() => {
            const bubble = document.getElementById(thinkingId);
            if(bubble) bubble.remove();

            let reply = database[database.length - 1].resp;
            const search = (forcedKey || text).toLowerCase();

            for(let item of database) {
                if(item.keys.some(k => search.includes(k))) {
                    reply = item.resp;
                    break;
                }
            }
            addMsg(reply, 'bot');
        }, 500);
    }

    function addMsg(txt, type) {
        const d = document.createElement('div');
        d.className = `msg ${type}`;
        d.innerHTML = txt; // Use innerHTML to render the <a> links
        history.appendChild(d);
        history.scrollTop = history.scrollHeight;
    }

    if(sendBtn) sendBtn.addEventListener('click', () => handleChat());
    if(input) input.addEventListener('keypress', (e) => { if(e.key==='Enter') handleChat(); });

    // ==========================================
    // 5. SCROLL ANIMATIONS (NEW FEATURE)
    // ==========================================
    // This triggers the fade-up effect for elements with .animate-up class
    const animatedElements = document.querySelectorAll('.animate-up');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    animatedElements.forEach((el) => observer.observe(el));
});

