<?php /* Template Name: Project: Moya */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <a href="<?php echo site_url('/projects'); ?>" class="back-link">
        <i class="fa-solid fa-chevron-left"></i> Back to Projects
    </a>

    <div class="project-hero gradient-blue">
        <div class="hero-icon">
            <i class="fa-solid fa-droplet"></i>
        </div>
        <div class="hero-text">
            <h1>Moya</h1>
            <p>Mineral Water Delivery and Ordering Management System. "Refill the Chill".</p>
        </div>
    </div>

    <div class="project-meta-grid">
        <div class="meta-column">
            <h3>About</h3>
            <p>A specialized delivery platform for Rosario, La Union. It allows customers to order mineral water containers and track delivery in real-time, targeting the Barangay Cataguingtingan area.</p>
        </div>
        <div class="meta-column">
            <h3>Info</h3>
            <ul class="info-list">
                <li><i class="fa-regular fa-calendar"></i> 2025</li>
                <li><i class="fa-solid fa-user-tag"></i> Role: Full Stack Developer</li>
                <li><i class="fa-solid fa-truck-fast"></i> Delivery System</li>
                <li>
                    <i class="fa-brands fa-github"></i> 
                    <a href="https://github.com/ikovlad/moya_mineralwater_delivery" target="_blank" style="color: inherit; text-decoration: underline; transition: 0.3s;">View on GitHub</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="features-section">
        <h3>Key Features</h3>
        <div class="features-grid">
            <ul class="check-list">
                <li><i class="fa-regular fa-circle-check"></i> Real-time Ordering</li>
                <li><i class="fa-regular fa-circle-check"></i> Delivery Area Mapping</li>
                <li><i class="fa-regular fa-circle-check"></i> Pricing Management</li>
                <li><i class="fa-regular fa-circle-check"></i> Fast Delivery (1-2 Hours)</li>
            </ul>
            
            <div class="tech-stack-column">
                <span class="tech-pill">PHP</span>
                <span class="tech-pill">SQL</span>
                <span class="tech-pill">JavaScript</span>
                <span class="tech-pill">HTML/CSS</span>
            </div>
        </div>
    </div>

</div>

<?php get_footer(); ?>