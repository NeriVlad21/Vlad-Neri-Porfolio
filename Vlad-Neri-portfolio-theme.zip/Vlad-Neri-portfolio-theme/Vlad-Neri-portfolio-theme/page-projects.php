<?php /* Template Name: Projects Page */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <h2 class="section-title">Projects</h2>

    <div class="project-grid">

        <a href="<?php echo site_url('/life-flow'); ?>" class="project-card gradient-red">
            <div class="project-icon">
                <i class="fa-solid fa-heart-pulse"></i>
            </div>
            <div class="project-info">
                <h3>Life Flow</h3>
                <p>School Project: Blood Donation Facilitation Website built with PHP & SQL.</p>
            </div>
        </a>

        <a href="<?php echo site_url('/moya'); ?>" class="project-card gradient-blue">
            <div class="project-icon">
                <i class="fa-solid fa-droplet"></i>
            </div>
            <div class="project-info">
                <h3>Moya</h3>
                <p>School Project: Mineral Water Delivery Management System for local businesses.</p>
            </div>
        </a>

        <a href="<?php echo site_url('/pennywise'); ?>" class="project-card gradient-green">
            <div class="project-icon">
                <i class="fa-solid fa-sack-dollar"></i>
            </div>
            <div class="project-info">
                <h3>PennyWise</h3>
                <p>School Project: Financial goal tracking android app built with Kotlin.</p>
            </div>
        </a>

        <a href="<?php echo site_url('/manga-haven'); ?>" class="project-card gradient-purple">
            <div class="project-icon">
                <i class="fa-solid fa-book-open"></i>
            </div>
            <div class="project-info">
                <h3>Manga Haven PH</h3>
                <p>School Project: Rental Bookstore Management Dashboard with analytics.</p>
            </div>
        </a>

    </div>
</div>

<?php get_footer(); ?>