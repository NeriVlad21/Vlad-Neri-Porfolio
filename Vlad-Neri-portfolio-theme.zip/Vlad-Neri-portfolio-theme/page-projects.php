<?php /* Template Name: Projects Page */ get_header(); ?>

<div class="mobile-container page-layout">
    
    <h2 class="section-title">Projects</h2>

    <div class="project-grid">

        <a href="<?php echo site_url('/life-flow'); ?>" class="project-card gradient-red">
            <div class="project-icon">
                <i class="fa-solid fa-heart-pulse"></i>
            </div>
            <div class="project-info">
                <h3>Life Flow</h3>
                <p>School Project: Blood Donation Facilitation Website built with PHP & SQL.</p>
            </div>
        </a>

        <a href="<?php echo site_url('/moya'); ?>" class="project-card gradient-blue">
            <div class="project-icon">
                <i class="fa-solid fa-droplet"></i>
            </div>
            <div class="project-info">
                <h3>Moya</h3>
                <p>School Project: Mineral Water Delivery Management System for local businesses.</p>
            </div>
        </a>

        <a href="<?php echo site_url('/pennywise'); ?>" class="project-card gradient-green">
            <div class="project-icon">
                <i class="fa-solid fa-sack-dollar"></i>
            </div>
            <div class="project-info">
                <h3>PennyWise</h3>
                <p>School Project: Financial goal tracking android app built with Kotlin.</p>
            </div>
        </a>

        <a href="<?php echo site_url('/manga-haven'); ?>" class="project-card gradient-purple">
            <div class="project-icon">
                <i class="fa-solid fa-book-open"></i>
            </div>
            <div class="project-info">
                <h3>Manga Haven PH</h3>
                <p>School Project: Rental Bookstore Management Dashboard with analytics.</p>
            </div>
        </a>

        <!-- NEW EXTERNAL PROJECT LINK -->
        <a href="https://foodrecom4panlasangpinoy.streamlit.app/" target="_blank" rel="noopener noreferrer" class="project-card gradient-gold">
            <div class="project-icon">
                <i class="fa-solid fa-utensils"></i>
            </div>
            <div class="project-info">
                <h3>Panlasang Pinoy AI</h3>
                <p>Personal Project: Food recommendation web app built with Python and Streamlit.</p>
            </div>
        </a>

        <a href="https://vladgpt.page.gd/?=1" target="_blank" rel="noopener noreferrer" class="project-card gradient-black">
            <div class="project-icon">
                <i class="fa-solid fa-computer"></i>
            </div>
            <div class="project-info">
                <h3>VladGPT - Portfolio Website</h3>
                <p>Personal Project: Mikael Vladimir M. Neri's portfolio</p>
            </div>
        </a>

    </div>
</div>

<?php get_footer(); ?>