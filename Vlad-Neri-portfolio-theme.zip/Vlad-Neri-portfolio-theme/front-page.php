<?php get_header(); ?>

<div class="mobile-container">
    <nav class="card-stack">
        
        <a href="<?php echo site_url('/projects'); ?>" class="menu-card">
            <div class="card-left">
                <div class="card-title-row">
                    <i class="fa-regular fa-folder"></i> 
                    <h3>Projects</h3>
                </div>
                <p>Life Flow, Moya, PennyWise, and school projects.</p>
            </div>
            <div class="card-right">
                <i class="fa-solid fa-arrow-right"></i>
            </div>
        </a>

        <a href="<?php echo site_url('/about'); ?>" class="menu-card">
            <div class="card-left">
                <div class="card-title-row">
                    <i class="fa-regular fa-user"></i> 
                    <h3>About</h3>
                </div>
                <p>4th Year CS Student & Aspiring Data Analyst.</p>
            </div>
            <div class="card-right">
                <i class="fa-solid fa-arrow-right"></i>
            </div>
        </a>

        <a href="<?php echo site_url('/work'); ?>" class="menu-card">
            <div class="card-left">
                <div class="card-title-row">
                    <i class="fa-solid fa-briefcase"></i> 
                    <h3>Work Experience</h3>
                </div>
                <p>Part-time roles and Summer jobs.</p>
            </div>
            <div class="card-right">
                <i class="fa-solid fa-arrow-right"></i>
            </div>
        </a>

        <a href="<?php echo site_url('/contact'); ?>" class="menu-card">
            <div class="card-left">
                <div class="card-title-row">
                    <i class="fa-regular fa-paper-plane"></i> 
                    <h3>Contact</h3>
                </div>
                <p>Email, Phone, and Socials.</p>
            </div>
            <div class="card-right">
                <i class="fa-solid fa-arrow-right"></i>
            </div>
        </a>

    </nav>
</div>

<?php get_footer(); ?>